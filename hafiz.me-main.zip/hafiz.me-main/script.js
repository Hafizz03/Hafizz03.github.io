console.log("Welcome to Hafiz's Website");
